## Projeto 3 de TI326 - Inteligência Artificial

## 🧑‍🎓 Integrantes

* Victor Hugo Barbosa dos Santos - 22152
* Pedro Henrique Batista Nunes - 22147

## 📝 Descrição

## 📋 Licença

Este projeto utiliza a licença [MIT](https://opensource.org/license/mit).
